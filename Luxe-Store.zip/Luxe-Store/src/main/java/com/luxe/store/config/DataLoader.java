package com.luxe.store.config;

import com.luxe.store.model.*;
import com.luxe.store.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class DataLoader {

    @Bean
    public CommandLineRunner initDatabase(ProductoRepository productoRepo,
                                          ClienteRepository clienteRepo,
                                          VentaRepository ventaRepo,
                                          UsuarioRepository usuarioRepo) {
        return args -> {
            // Seed Productos con imágenes
            if (productoRepo.count() == 0) {
                productoRepo.save(new Producto(null, "PL001", "Polo Algodón Premium", "Polos", "M", "Negro", 45.00, 25, "Activo", "/img/productos/polo_negro.jpg"));
                productoRepo.save(new Producto(null, "CM002", "Camisa Oxford Slim", "Camisas", "L", "Azul", 75.00, 12, "Activo", "/img/productos/camisa_oxford_azul.jpg"));
                productoRepo.save(new Producto(null, "PA003", "Pantalón Denim Clásico", "Pantalones", "32", "Azul Oscuro", 95.00, 4, "Activo", "/img/productos/pantalon_denim.jpg"));
                productoRepo.save(new Producto(null, "PL004", "Polo Oversize Luxe", "Polos", "L", "Blanco", 55.00, 18, "Activo", "/img/productos/polo_blanco.jpg"));
                productoRepo.save(new Producto(null, "CM005", "Camisa Casual Manga Larga", "Camisas", "M", "Verde", 69.90, 8, "Activo", "/img/productos/camisa_casual_verde.jpg"));
                productoRepo.save(new Producto(null, "CS006", "Casaca Bomber Urbana", "Casacas", "L", "Negro", 149.00, 10, "Activo", "/img/productos/casaca_bomber.jpg"));
                productoRepo.save(new Producto(null, "PA007", "Pantalón Cargo Beige", "Pantalones", "30", "Beige", 89.90, 15, "Activo", "/img/productos/pantalon_cargo.jpg"));
            }

            // Seed Clientes
            if (clienteRepo.count() == 0) {
                clienteRepo.save(new Cliente(null, "DNI", "74829103", "Carlos Mendoza Ruiz", "987654321", "carlos.mendoza@gmail.com", "Activo"));
                clienteRepo.save(new Cliente(null, "DNI", "45910283", "María López Torres", "912345678", "maria.lopez@hotmail.com", "Activo"));
                clienteRepo.save(new Cliente(null, "RUC", "20601234567", "Inversiones Textil S.A.C.", "014258900", "contacto@textil.pe", "Activo"));
            }

            // Seed Usuarios
            if (usuarioRepo.count() == 0) {
                String adminPassword = System.getenv("ADMIN_INITIAL_PASSWORD");
                String vendedorPassword = System.getenv("VENDEDOR_INITIAL_PASSWORD");
                if (adminPassword == null || adminPassword.length() < 10
                        || vendedorPassword == null || vendedorPassword.length() < 10) {
                    throw new IllegalStateException("Configure ADMIN_INITIAL_PASSWORD y VENDEDOR_INITIAL_PASSWORD (mínimo 10 caracteres) para crear las cuentas iniciales.");
                }
                BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
                usuarioRepo.save(new Usuario(null, "Administrador Principal", "admin@luxe.pe", "admin", encoder.encode(adminPassword), "ADMIN", "Activo"));
                usuarioRepo.save(new Usuario(null, "Juan Pérez", "vendedor@luxe.pe", "vendedor", encoder.encode(vendedorPassword), "VENDEDOR", "Activo"));
            }

            // Seed Ventas Iniciales
            if (ventaRepo.count() == 0) {
                Cliente c1 = clienteRepo.findByNumeroDocumento("74829103").orElse(null);
                Producto p1 = productoRepo.findByCodigo("PL001").orElse(null);
                Producto p2 = productoRepo.findByCodigo("CM002").orElse(null);

                if (p1 != null && p2 != null) {
                    List<DetalleVenta> dv = new ArrayList<>();
                    dv.add(new DetalleVenta(null, p1, 2, p1.getPrecio(), p1.getPrecio() * 2));
                    dv.add(new DetalleVenta(null, p2, 1, p2.getPrecio(), p2.getPrecio() * 1));

                    Venta v = new Venta(null, "#TLX-00245", "03/09/2026", c1, "Juan Pérez", dv, "Yape/Plin", 165.00, 165.00, 0.0, "Completado");
                    dv.forEach(det -> det.setVenta(v));
                    ventaRepo.save(v);
                }
            }
        };
    }
}
